package com.example.staffapp;

public class GetBaseURL {
    private final String IP_ADDRESS = "http://localhost:8080/";
    public String getIpAddress(){ return IP_ADDRESS; }
}
